#pragma once

// Klasi simeio 2d xwrou
class Point2D
{
public:
	float x, y;
};