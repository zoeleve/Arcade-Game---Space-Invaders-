#pragma once


// Rythmiseis tou paixnidiou
#define window_title "Space Invaders"
#define canvas_width  1100
#define canvas_height  500
#define window_width  1200
#define window_height  600
#define assets_path   "assets\\"
